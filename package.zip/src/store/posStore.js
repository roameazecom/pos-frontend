import { create } from 'zustand';
import toast from 'react-hot-toast';
import axios from 'axios';
import { io } from 'socket.io-client';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
// Initialize Socket.io
const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || 'http://localhost:5000';
const socket = io(SOCKET_URL);

export const usePosStore = create((set, get) => ({
  orders: [],
  orderHistory: [],
  tables: [],
  menuItems: [],
  categories: [],
  locations: [],

  // UI state for Waiter App
  activeTableId: null,
  cart: [],

  restaurantDetails: null,

  // Notifications
  notifications: [],
  unreadNotificationsCount: 0,
  addNotification: (message, type, audioType) => set(state => {
    playSound(audioType);
    const newNotif = { id: Date.now(), message, type, time: Date.now(), read: false };
    return { 
      notifications: [newNotif, ...state.notifications],
      unreadNotificationsCount: state.unreadNotificationsCount + 1
    };
  }),
  markNotificationsRead: () => set(state => ({
    notifications: state.notifications.map(n => ({ ...n, read: true })),
    unreadNotificationsCount: 0
  })),

  // INITIALIZATION
  fetchData: async () => {
    try {
      const [catRes, menuRes, locRes, tableRes, orderRes, restRes] = await Promise.all([
        axios.get(`${API_URL}/config/categories`),
        axios.get(`${API_URL}/config/menu-items`),
        axios.get(`${API_URL}/config/locations`),
        axios.get(`${API_URL}/config/tables`),
        axios.get(`${API_URL}/orders`),
        axios.get(`${API_URL}/restaurant`)
      ]);
      set({
        categories: catRes.data,
        menuItems: menuRes.data,
        locations: locRes.data,
        tables: tableRes.data,
        orders: orderRes.data,
        restaurantDetails: restRes.data
      });
      // also fetch history
      get().fetchOrderHistory();
    } catch (err) {
      console.error('Failed to fetch data', err);
      toast.error('Failed to load POS data');
    }
  },

  fetchOrderHistory: async () => {
    try {
      const res = await axios.get(`${API_URL}/orders/history`);
      set({ orderHistory: res.data });
    } catch (err) {
      console.error('Failed to fetch order history', err);
    }
  },

  setActiveTableId: (id) => set({ activeTableId: id }),
  
  addToCart: (item) => set((state) => {
    const existing = state.cart.find(i => i.menu_item_id === item.id);
    if (existing) {
      return { cart: state.cart.map(i => i.menu_item_id === item.id ? { ...i, quantity: i.quantity + 1 } : i) };
    }
    return { cart: [...state.cart, { id: Date.now(), menu_item_id: item.id, quantity: 1, name: item.name, price: item.price, status: 'pending' }] };
  }),

  removeFromCart: (itemId) => set((state) => ({
    cart: state.cart.filter(i => i.menu_item_id !== itemId)
  })),

  updateCartQuantity: (itemId, quantity) => set((state) => ({
    cart: state.cart.map(i => i.menu_item_id === itemId ? { ...i, quantity } : i)
  })),

  clearCart: () => set({ cart: [] }),

  // Actions
  placeOrder: async (userId = null, orderType = 'dine_in', customerName = '', customerPhone = '') => {
    const state = get();
    if (orderType === 'dine_in' && !state.activeTableId) return;
    if (state.cart.length === 0) return;

    const cartSubtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    try {
      await axios.post(`${API_URL}/orders`, {
        table_id: orderType === 'dine_in' ? state.activeTableId : null,
        items: state.cart,
        subtotal: cartSubtotal,
        user_id: userId,
        order_type: orderType,
        customer_name: customerName,
        customer_phone: customerPhone
      });
      
      toast.success(`Order placed and sent to kitchen!`, { position: 'bottom-center' });
      set({ cart: [] });
      // We don't manually update local state; we wait for the socket event to trigger fetchData()
    } catch (err) {
      console.error(err);
      toast.error('Failed to place order');
    }
  },

  checkoutOrder: async (orderId, paymentType = 'Cash', customerName = '', customerPhone = '', userId = null, discountAmount = 0) => {
    try {
      await axios.post(`${API_URL}/orders/${orderId}/checkout`, { 
        payment_type: paymentType,
        customer_name: customerName,
        customer_phone: customerPhone,
        user_id: userId,
        discount_amount: discountAmount
      });
      toast.success(`Bill closed successfully! (${paymentType})`);
    } catch (err) {
      console.error(err);
      toast.error('Failed to checkout');
    }
  },

  quickBillOrder: async (orderType = 'takeaway', paymentType = 'Cash', customerName = '', customerPhone = '', discountAmount = 0, userId = null) => {
    const state = get();
    if (state.cart.length === 0) return null;

    const cartSubtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    try {
      const res = await axios.post(`${API_URL}/orders/quick-bill`, {
        items: state.cart,
        subtotal: cartSubtotal,
        user_id: userId,
        order_type: orderType,
        customer_name: customerName,
        customer_phone: customerPhone,
        payment_type: paymentType,
        discount_amount: discountAmount
      });
      
      toast.success(`Quick Bill generated successfully!`);
      set({ cart: [] });
      return res.data.orderId;
    } catch (err) {
      console.error(err);
      toast.error('Failed to generate quick bill');
      return null;
    }
  },

  // KDS actions
  updateItemStatus: async (orderId, itemId, newStatus) => {
    try {
      await axios.put(`${API_URL}/orders/${orderId}/items/${itemId}`, { status: newStatus });
      if (newStatus === 'ready') toast.success(`Item is Ready!`);
    } catch (err) {
      console.error(err);
      toast.error('Failed to update status');
    }
  },

  updateKotStatus: async (orderId, kotId, newStatus) => {
    try {
      await axios.put(`${API_URL}/orders/${orderId}/kot/${kotId}`, { status: newStatus });
      if (newStatus === 'ready') toast.success(`KOT ${kotId} is Ready!`, { duration: 5000, icon: '🍲' });
    } catch (err) {
      console.error(err);
      toast.error('Failed to update KOT status');
    }
  },

  // Admin Configuration CRUD
  addCategory: async (category) => {
    try {
      const res = await axios.post(`${API_URL}/config/categories`, category);
      set((state) => ({ categories: [...state.categories, res.data] }));
    } catch (err) { console.error(err); }
  },
  
  addMenuItem: async (item) => {
    try {
      const res = await axios.post(`${API_URL}/config/menu-items`, item);
      set((state) => ({ menuItems: [...state.menuItems, res.data] }));
    } catch (err) { console.error(err); }
  },
  
  addLocation: async (loc) => {
    try {
      const res = await axios.post(`${API_URL}/config/locations`, loc);
      set((state) => ({ locations: [...state.locations, res.data] }));
    } catch (err) { console.error(err); }
  },
  
  addTable: async (table) => {
    try {
      const res = await axios.post(`${API_URL}/config/tables`, table);
      set((state) => ({ tables: [...state.tables, res.data] }));
    } catch (err) { console.error(err); }
  },
  
  // Notice: For brevity, updates and deletes would be implemented similarly using axios.put and axios.delete.
  // The local state should be updated to reflect changes immediately or wait for a fetch.
  updateCategory: () => {}, deleteCategory: () => {},
  updateMenuItem: () => {}, deleteMenuItem: () => {},
  updateLocation: () => {}, deleteLocation: () => {},
  updateTable: () => {}, deleteTable: () => {}
}));

// Helper to play synthesized sounds
const playSound = (type) => {
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;
    const ctx = new AudioContext();
    
    if (type === 'new_order') {
      // Loud double beep for kitchen
      const playBeep = (delay) => {
        setTimeout(() => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'square';
          osc.frequency.setValueAtTime(800, ctx.currentTime);
          gain.gain.setValueAtTime(0.3, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start();
          osc.stop(ctx.currentTime + 0.2);
        }, delay);
      };
      playBeep(0);
      playBeep(250);
    } else if (type === 'ready_order') {
      // Pleasant ding for waiter
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1046.50, ctx.currentTime); // C6
      gain.gain.setValueAtTime(0.4, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 1.2);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 1.2);
    }
  } catch (err) {
    console.error("Audio play failed:", err);
  }
};

// Real-Time Socket Synchronization
socket.on('order_updated', (data) => {
  console.log('Socket event received:', data);
  const store = usePosStore.getState();
  
  if (data.action === 'new_kot') {
    // Notify Kitchen
    store.addNotification(`New KOT Received for Table ${data.table_id || '?'}`, 'info', 'new_order');
  } else if (data.action === 'item_status' || data.action === 'kot_status') {
    // Notify Waiter if ready
    if (data.status === 'ready') {
      store.addNotification(`Order items are Ready to Serve!`, 'success', 'ready_order');
      toast.success('🛎️ Order Ready to Serve!', { id: 'order-update-toast', icon: '🍲' });
    } else {
      store.addNotification(`Order status updated to ${data.status}`, 'info', null);
    }
  }

  // Re-fetch all data to ensure synchronization
  store.fetchData();
});
