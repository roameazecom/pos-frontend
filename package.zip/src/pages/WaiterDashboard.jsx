import { useState } from 'react';
import { usePosStore } from '../store/posStore';
import { useUiStore } from '../store/uiStore';
import { useAuthStore } from '../store/authStore';
import {
  Plus, Minus, Trash2, Send, Clock, Flame, CheckCircle2,
  History, Banknote, CreditCard, User, Phone, X, Coffee,
  Receipt, ShoppingBag, Bike, ChevronDown
} from 'lucide-react';
import WaiterPaymentHistory from '../components/waiter/WaiterPaymentHistory';
import NotificationPanel from '../components/common/NotificationPanel';

export default function WaiterDashboard() {
  const { user } = useAuthStore();
  const {
    tables, locations, categories, menuItems, orders,
    activeTableId, setActiveTableId,
    cart, addToCart, removeFromCart, updateCartQuantity, clearCart, placeOrder, checkoutOrder
  } = usePosStore();

  const { activeLocationTab, setActiveLocationTab, activeCategoryTab, setActiveCategoryTab } = useUiStore();

  const [rightTab, setRightTab] = useState('new');
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [orderType, setOrderType] = useState('dine_in');
  const [takeawayName, setTakeawayName] = useState('');
  const [takeawayPhone, setTakeawayPhone] = useState('');
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [paymentType, setPaymentType] = useState('Cash');
  const [checkoutName, setCheckoutName] = useState('');
  const [checkoutPhone, setCheckoutPhone] = useState('');

  const filteredTables = tables.filter(t => t.location_id === activeLocationTab);
  const activeTable = tables.find(t => t.id === activeTableId);
  const filteredMenu = menuItems.filter(m => m.category_id === activeCategoryTab && m.is_available);
  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const activeOrder = orderType === 'dine_in' ? orders.find(o => o.table_id === activeTableId && o.status === 'open') : null;
  const canOrder = orderType === 'dine_in' ? !!activeTableId : true;

  const handleCheckoutClick = (type) => { setPaymentType(type); setShowCheckoutModal(true); };
  const handleConfirmPayment = () => {
    if (activeOrder) {
      checkoutOrder(activeOrder.id, paymentType, checkoutName, checkoutPhone, user?.id);
      setShowCheckoutModal(false);
      setCheckoutName(''); setCheckoutPhone(''); setRightTab('new');
    }
  };
  const handlePlaceOrder = () => {
    placeOrder(user?.id, orderType, takeawayName, takeawayPhone);
    if (orderType === 'dine_in') setRightTab('active');
    else { setTakeawayName(''); setTakeawayPhone(''); }
  };

  const ORDER_TYPES = [
    { id: 'dine_in', label: 'Dine-In', icon: Coffee, color: '#fb923c' },
    { id: 'takeaway', label: 'Takeaway', icon: ShoppingBag, color: '#a78bfa' },
    { id: 'delivery', label: 'Delivery', icon: Bike, color: '#34d399' },
  ];

  const panelStyle = {
    background: 'rgba(255, 255, 255, 0.85)',
    backdropFilter: 'blur(20px)',
    WebkitBackdropFilter: 'blur(20px)',
    border: '1px solid rgba(0, 0, 0, 0.08)',
  };

  return (
    <div className="flex flex-col lg:flex-row h-full overflow-y-auto lg:overflow-hidden relative font-sans"
         style={{ background: '#f8fafc', minHeight: '100vh' }}>

      {/* ══════════ LEFT PANEL ══════════ */}
      <div className="flex-1 flex flex-col min-w-0 lg:h-full z-10">

        {/* Header: Order Type + Tables */}
        <div className="sticky top-0 z-20 shrink-0 p-4 lg:p-5 space-y-4"
             style={panelStyle}>

          {/* Order Type Switcher */}
          <div className="flex gap-2">
            {ORDER_TYPES.map(({ id, label, icon: Icon, color }) => (
              <button
                key={id}
                onClick={() => { setOrderType(id); setRightTab('new'); if (id !== 'dine_in') setActiveTableId(null); }}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-sm font-bold transition-all duration-300"
                style={orderType === id ? {
                  background: `${color}18`,
                  border: `1px solid ${color}50`,
                  color: color,
                  boxShadow: `0 0 15px ${color}20`
                } : {
                  background: 'rgba(255,255,255,0.85)',
                  border: '1px solid rgba(0,0,0,0.06)',
                  color: 'rgba(15,23,42,0.5)'
                }}
              >
                <Icon className="w-4 h-4" />
                {label}
              </button>
            ))}
          </div>

          {/* Dine-In: Locations + Tables */}
          {orderType === 'dine_in' ? (
            <div className="space-y-3">
              {/* Location tabs */}
              <div className="flex gap-2 overflow-x-auto custom-scrollbar pb-1">
                {locations.map(loc => (
                  <button
                    key={loc.id}
                    onClick={() => { setActiveLocationTab(loc.id); setActiveTableId(null); setRightTab('new'); }}
                    className="px-4 py-2 rounded-lg text-xs font-bold whitespace-nowrap transition-all duration-300 shrink-0"
                    style={activeLocationTab === loc.id ? {
                      background: 'linear-gradient(135deg, #f97316, #ea580c)',
                      color: 'white',
                      boxShadow: '0 4px 12px rgba(249,115,22,0.35)'
                    } : {
                      background: 'rgba(255,255,255,0.85)',
                      border: '1px solid rgba(0,0,0,0.07)',
                      color: 'rgba(15,23,42,0.55)'
                    }}
                  >
                    {loc.name}
                  </button>
                ))}
              </div>

              {/* Table grid */}
              <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-8 gap-2.5">
                {filteredTables.map(t => {
                  const isSelected = activeTableId === t.id;
                  const isOccupied = t.status === 'occupied';
                  return (
                    <button
                      key={t.id}
                      onClick={() => {
                        setActiveTableId(t.id);
                        if (t.status === 'occupied') setRightTab('active');
                        else setRightTab('new');
                      }}
                      className="relative p-3 rounded-xl text-center transition-all duration-300 hover-lift"
                      style={isSelected ? {
                        background: 'rgba(249,115,22,0.12)',
                        border: '2px solid rgba(249,115,22,0.55)',
                        boxShadow: '0 0 20px rgba(249,115,22,0.12)'
                      } : isOccupied ? {
                        background: 'rgba(251,191,36,0.08)',
                        border: '1px solid rgba(251,191,36,0.25)'
                      } : {
                        background: 'rgba(255,255,255,0.85)',
                        border: '1px solid rgba(0,0,0,0.06)'
                      }}
                    >
                      <span className="block text-lg font-black"
                        style={{ color: isSelected ? '#ea580c' : isOccupied ? '#b45309' : 'rgba(15,23,42,0.8)' }}>
                        {t.table_number}
                      </span>
                      <span className="text-[9px] uppercase tracking-wider font-bold"
                        style={{ color: isOccupied ? '#b45309' : 'rgba(15,23,42,0.4)' }}>
                        {t.status === 'occupied' ? '● Busy' : '○ Free'}
                      </span>
                      {isSelected && (
                        <div className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full flex items-center justify-center animate-pulse-glow"
                             style={{ background: '#f97316' }}>
                          <CheckCircle2 className="w-2.5 h-2.5 text-white" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ) : (
            /* Takeaway / Delivery: Customer fields */
            <div className="p-4 rounded-2xl space-y-3 animate-fade-in" style={{
              background: 'rgba(255,255,255,0.85)',
              border: '1px solid rgba(0,0,0,0.06)'
            }}>
              <p className="text-xs font-bold uppercase tracking-widest" style={{ color: 'rgba(15,23,42,0.5)' }}>
                Customer Info (Optional)
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  type="text" placeholder="Customer Name" value={takeawayName}
                  onChange={(e) => setTakeawayName(e.target.value)}
                  className="glass-input flex-1 px-4 py-2.5 rounded-xl text-sm font-medium"
                />
                <input
                  type="tel" placeholder="Phone Number" value={takeawayPhone}
                  onChange={(e) => setTakeawayPhone(e.target.value)}
                  className="glass-input flex-1 px-4 py-2.5 rounded-xl text-sm font-medium"
                />
              </div>
            </div>
          )}
        </div>

        {/* Menu Section */}
        <div className={`flex-1 flex flex-col min-h-[400px] lg:min-h-0 transition-all duration-300 ${!canOrder ? 'opacity-30 pointer-events-none' : ''}`}>

          {/* Category bar */}
          <div className="sticky top-0 z-10 px-4 lg:px-5 py-3 shrink-0" style={{
            background: 'rgba(255, 255, 255, 0.9)',
            backdropFilter: 'blur(12px)',
            borderBottom: '1px solid rgba(0, 0, 0, 0.06)'
          }}>
            <div className="flex gap-2 overflow-x-auto custom-scrollbar pb-1">
              {categories.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategoryTab(cat.id)}
                  className="px-5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all duration-300 shrink-0"
                  style={activeCategoryTab === cat.id ? {
                    background: 'linear-gradient(135deg, #f97316, #ea580c)',
                    color: 'white',
                    boxShadow: '0 3px 12px rgba(249,115,22,0.4)'
                  } : {
                    background: 'rgba(255,255,255,0.85)',
                    border: '1px solid rgba(0, 0, 0, 0.06)',
                    color: 'rgba(15, 23, 42, 0.5)'
                  }}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          {/* Menu Grid */}
          <div className="flex-1 overflow-y-auto p-4 lg:p-5 custom-scrollbar">
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3 lg:gap-4">
              {filteredMenu.map(item => (
                <button
                  key={item.id}
                  onClick={() => { addToCart(item); setRightTab('new'); }}
                  className="menu-item-card flex flex-col text-left p-4 rounded-2xl group"
                >
                  {/* Price badge */}
                  <div className="flex items-start justify-between mb-3">
                    <span className="text-xs font-black px-2.5 py-1 rounded-lg"
                      style={{ background: 'rgba(249,115,22,0.1)', color: '#ea580c', border: '1px solid rgba(249,115,22,0.2)' }}>
                      ₹{item.price}
                    </span>
                    <div className="w-8 h-8 rounded-xl flex items-center justify-center transition-all duration-300 shrink-0"
                      style={{ background: 'rgba(255,255,255,0.8)', border: '1px solid rgba(0, 0, 0, 0.08)' }}
                      onMouseEnter={e => {
                        e.currentTarget.style.background = 'rgba(249,115,22,0.2)';
                        e.currentTarget.style.border = '1px solid rgba(249,115,22,0.4)';
                      }}
                      onMouseLeave={e => {
                        e.currentTarget.style.background = 'rgba(255,255,255,0.8)';
                        e.currentTarget.style.border = '1px solid rgba(0, 0, 0, 0.08)';
                      }}
                    >
                      <Plus className="w-4 h-4" style={{ color: '#ea580c' }} />
                    </div>
                  </div>
                  <span className="font-bold text-sm text-surface-100 truncate block w-full group-hover:text-orange-600 transition-colors">
                    {item.name}
                  </span>
                  <span className="text-xs mt-1 line-clamp-2 leading-snug text-surface-400">
                    {item.description}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ══════════ RIGHT PANEL: Cart ══════════ */}
      <div className="w-full lg:w-[380px] flex flex-col shrink-0 lg:h-full h-[500px] z-20"
           style={{ ...panelStyle, borderLeft: '1px solid rgba(0,0,0,0.08)' }}>

        {/* Cart Header */}
        <div className="shrink-0" style={{ borderBottom: '1px solid rgba(0,0,0,0.08)' }}>
          <div className="px-5 py-4 flex items-center justify-between">
            <h2 className="text-xl font-black text-surface-100 flex items-center gap-2">
              Order
              {orderType === 'dine_in' && activeTable && (
                <span className="text-xs px-2.5 py-1 rounded-lg font-bold"
                  style={{ background: 'rgba(249,115,22,0.1)', color: '#ea580c', border: '1px solid rgba(249,115,22,0.2)' }}>
                  T-{activeTable.table_number}
                </span>
              )}
              {orderType !== 'dine_in' && (
                <span className="text-xs px-2.5 py-1 rounded-lg font-bold"
                  style={orderType === 'takeaway' ? { background: 'rgba(167,139,250,0.1)', color: '#6d28d9', border: '1px solid rgba(167,139,250,0.2)' }
                                                  : { background: 'rgba(52,211,153,0.1)', color: '#047857', border: '1px solid rgba(52,211,153,0.2)' }}>
                  {orderType === 'takeaway' ? 'Takeaway' : 'Delivery'}
                </span>
              )}
            </h2>
            <NotificationPanel />
          </div>

          {/* Tabs */}
          <div className="flex px-5 gap-4" style={{ borderBottom: '1px solid rgba(0,0,0,0.08)' }}>
            <button
              onClick={() => setRightTab('new')}
              className={`pb-3 text-sm font-bold transition-all ${rightTab === 'new' ? 'tab-active' : 'tab-inactive'}`}
            >
              New{' '}
              {cart.length > 0 && (
                <span className="ml-1.5 px-1.5 py-0.5 rounded-md text-xs"
                  style={{ background: 'rgba(249,115,22,0.12)', color: '#ea580c' }}>
                  {cart.length}
                </span>
              )}
            </button>
            {orderType === 'dine_in' && (
              <button
                onClick={() => setRightTab('active')}
                className={`pb-3 text-sm font-bold transition-all ${rightTab === 'active' ? 'tab-active' : 'tab-inactive'}`}
              >
                Active Bill
              </button>
            )}
            <div className="flex-1" />
            <button
              onClick={() => setShowHistoryModal(true)}
              className="pb-3 text-sm font-bold flex items-center gap-1.5 transition-colors"
              style={{ color: 'rgba(15, 23, 42, 0.45)' }}
              onMouseEnter={e => e.currentTarget.style.color = '#ea580c'}
              onMouseLeave={e => e.currentTarget.style.color = 'rgba(15, 23, 42, 0.45)'}
            >
              <History className="w-4 h-4" />
              History
            </button>
          </div>
        </div>

        {/* Cart Content */}
        <div className="flex-1 overflow-y-auto p-4 custom-scrollbar relative">
          {!canOrder ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center"
                   style={{ background: 'rgba(0,0,0,0.03)', border: '1px solid rgba(0,0,0,0.06)' }}>
                <Coffee className="w-8 h-8" style={{ color: 'rgba(15, 23, 42, 0.3)' }} />
              </div>
              <p className="text-sm font-bold" style={{ color: 'rgba(15, 23, 42, 0.5)' }}>Select a table to start</p>
            </div>
          ) : rightTab === 'new' ? (
            cart.length === 0 ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 animate-fade-in">
                <div className="w-16 h-16 rounded-2xl flex items-center justify-center"
                     style={{ background: 'rgba(0,0,0,0.02)', border: '1px dashed rgba(0,0,0,0.1)' }}>
                  <Receipt className="w-8 h-8" style={{ color: 'rgba(15, 23, 42, 0.3)' }} />
                </div>
                <p className="text-sm font-bold" style={{ color: 'rgba(15, 23, 42, 0.5)' }}>Cart is empty</p>
                <p className="text-xs" style={{ color: 'rgba(15, 23, 42, 0.4)' }}>Add items from the menu</p>
              </div>
            ) : (
              <div className="space-y-2.5 pb-4">
                {cart.map(item => (
                  <div key={item.id} className="p-4 rounded-2xl flex items-center justify-between gap-3 animate-fade-in transition-all"
                       style={{ background: 'rgba(0,0,0,0.02)', border: '1px solid rgba(0,0,0,0.06)' }}>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-surface-100 text-sm truncate">{item.name}</h4>
                      <span className="text-xs font-black mt-1 inline-block px-2 py-0.5 rounded-md"
                         style={{ background: 'rgba(249,115,22,0.1)', color: '#ea580c' }}>
                        ₹{item.price}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 rounded-xl p-1"
                         style={{ background: 'rgba(255,255,255,0.9)', border: '1px solid rgba(0,0,0,0.08)' }}>
                      <button
                        onClick={() => item.quantity > 1 ? updateCartQuantity(item.menu_item_id, item.quantity - 1) : removeFromCart(item.menu_item_id)}
                        className="w-7 h-7 rounded-lg flex items-center justify-center transition-all"
                        style={{ background: 'rgba(0,0,0,0.05)', color: 'rgba(15, 23, 42, 0.6)' }}
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="font-black text-surface-100 text-sm min-w-[20px] text-center">{item.quantity}</span>
                      <button
                        onClick={() => updateCartQuantity(item.menu_item_id, item.quantity + 1)}
                        className="w-7 h-7 rounded-lg flex items-center justify-center transition-all"
                        style={{ background: 'rgba(249,115,22,0.12)', color: '#ea580c' }}
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <button
                      onClick={() => removeFromCart(item.menu_item_id)}
                      className="w-8 h-8 rounded-xl flex items-center justify-center transition-all"
                      style={{ color: 'rgba(15, 23, 42, 0.4)' }}
                      onMouseEnter={e => { e.currentTarget.style.background = 'rgba(239,68,68,0.08)'; e.currentTarget.style.color = '#dc2626'; }}
                      onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'rgba(15, 23, 42, 0.4)'; }}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )
          ) : (
            /* Active Bill Tab */
            !activeOrder || activeOrder.items.length === 0 ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 animate-fade-in">
                <div className="w-16 h-16 rounded-2xl flex items-center justify-center"
                     style={{ background: 'rgba(0,0,0,0.02)', border: '1px dashed rgba(0,0,0,0.1)' }}>
                  <Receipt className="w-8 h-8" style={{ color: 'rgba(15, 23, 42, 0.3)' }} />
                </div>
                <p className="text-sm font-bold" style={{ color: 'rgba(15, 23, 42, 0.5)' }}>No active items</p>
              </div>
            ) : (
              <div className="space-y-2.5 animate-fade-in pb-4">
                {activeOrder.items.map((item, index) => (
                  <div key={item.id || index} className="p-4 rounded-2xl flex items-center justify-between transition-all"
                       style={{ background: 'rgba(0,0,0,0.02)', border: '1px solid rgba(0,0,0,0.06)' }}>
                    <div className="flex-1">
                      <h4 className="font-bold text-surface-100 text-sm">{item.name}</h4>
                      <p className="text-xs mt-1 font-bold" style={{ color: 'rgba(15, 23, 42, 0.5)' }}>
                        {item.quantity} × ₹{item.price}
                      </p>
                    </div>
                    <div className="flex flex-col items-end gap-1.5">
                      <span className="font-black text-surface-100 text-base">₹{item.quantity * item.price}</span>
                      <span className={`flex items-center gap-1 text-[10px] uppercase font-black px-2 py-0.5 rounded-md
                        ${item.status === 'pending' ? 'badge-pending' : item.status === 'cooking' ? 'badge-cooking' : 'badge-ready'}`}>
                        {item.status === 'pending' && <Clock className="w-2.5 h-2.5" />}
                        {item.status === 'cooking' && <Flame className="w-2.5 h-2.5" />}
                        {item.status === 'ready' && <CheckCircle2 className="w-2.5 h-2.5" />}
                        {item.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )
          )}
        </div>

        {/* Cart Footer */}
        <div className="shrink-0 p-4 lg:p-5 z-30"
             style={{ borderTop: '1px solid rgba(0,0,0,0.08)', background: 'rgba(255,255,255,0.9)', backdropFilter: 'blur(20px)' }}>
          {rightTab === 'new' ? (
            <>
              <div className="flex justify-between items-center mb-4">
                <span className="text-xs font-bold uppercase tracking-wider" style={{ color: 'rgba(15, 23, 42, 0.5)' }}>Subtotal</span>
                <span className="text-2xl font-black text-surface-100">₹{cartTotal}</span>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={clearCart}
                  disabled={cart.length === 0}
                  className="px-5 py-3 rounded-xl font-bold text-sm transition-all disabled:opacity-40"
                  style={{ background: 'rgba(0,0,0,0.04)', border: '1px solid rgba(0,0,0,0.08)', color: 'rgba(15, 23, 42, 0.55)' }}
                >
                  Clear
                </button>
                <button
                  onClick={handlePlaceOrder}
                  disabled={cart.length === 0}
                  className="btn-orange flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm disabled:opacity-40"
                >
                  <span className="relative z-10">
                    {orderType === 'dine_in' ? 'Send to Kitchen' : `Place ${orderType === 'takeaway' ? 'Takeaway' : 'Delivery'}`}
                  </span>
                  <Send className="w-4 h-4 relative z-10" />
                </button>
              </div>
            </>
          ) : (
            <>
              <div className="flex justify-between items-center mb-4">
                <span className="text-xs font-bold uppercase tracking-wider" style={{ color: 'rgba(15, 23, 42, 0.5)' }}>Total Due</span>
                <span className="text-2xl font-black" style={{ color: '#ea580c' }}>₹{activeOrder?.subtotal || 0}</span>
              </div>
              {activeOrder && activeOrder.items.length > 0 && (
                <div className="grid grid-cols-2 gap-2.5">
                  {[
                    { label: 'Cash', type: 'Cash', icon: Banknote, color: '#047857', bg: 'rgba(52,211,153,0.1)', border: 'rgba(52,211,153,0.2)' },
                    { label: 'UPI', type: 'UPI', icon: CreditCard, color: '#6d28d9', bg: 'rgba(167,139,250,0.1)', border: 'rgba(167,139,250,0.2)' },
                  ].map(({ label, type, icon: Icon, color, bg, border }) => (
                    <button
                      key={type}
                      onClick={() => handleCheckoutClick(type)}
                      className="flex items-center justify-center gap-2 p-3 rounded-xl font-black text-sm transition-all hover-lift active:scale-95"
                      style={{ background: bg, border: `1px solid ${border}`, color }}
                    >
                      <Icon className="w-4 h-4" /> {label}
                    </button>
                  ))}
                  <button
                    onClick={() => handleCheckoutClick('Card')}
                    className="col-span-2 flex items-center justify-center gap-2 p-3 rounded-xl font-black text-sm transition-all hover-lift active:scale-95"
                    style={{ background: 'rgba(96,165,250,0.1)', border: '1px solid rgba(96,165,250,0.2)', color: '#1d4ed8' }}
                  >
                    <CreditCard className="w-4 h-4" /> Card Payment
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* History Modal */}
      {showHistoryModal && <WaiterPaymentHistory onClose={() => setShowHistoryModal(false)} />}

      {/* Checkout Modal */}
      {showCheckoutModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 backdrop-blur-sm" style={{ background: 'rgba(0,0,0,0.35)' }}
               onClick={() => setShowCheckoutModal(false)} />
          <div className="w-full max-w-md rounded-3xl overflow-hidden animate-slide-up relative z-10"
               style={{ background: 'rgba(255, 255, 255, 0.95)', border: '1px solid rgba(0, 0, 0, 0.1)', backdropFilter: 'blur(30px)' }}>

            {/* Orange top bar */}
            <div className="h-1 w-full" style={{ background: 'linear-gradient(90deg, #f97316, #ea580c)' }} />

            <div className="p-6 flex justify-between items-center" style={{ borderBottom: '1px solid rgba(0, 0, 0, 0.08)' }}>
              <h3 className="font-black text-xl text-surface-100">Pay via {paymentType}</h3>
              <button onClick={() => setShowCheckoutModal(false)}
                className="w-8 h-8 rounded-xl flex items-center justify-center transition-all"
                style={{ background: 'rgba(0,0,0,0.04)', color: 'rgba(15, 23, 42, 0.5)' }}>
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div className="p-4 rounded-2xl flex justify-between items-center" style={{ background: 'rgba(249,115,22,0.08)', border: '1px solid rgba(249,115,22,0.2)' }}>
                <span className="font-bold text-sm" style={{ color: 'rgba(15, 23, 42, 0.6)' }}>Total Amount</span>
                <span className="text-3xl font-black" style={{ color: '#ea580c' }}>₹{activeOrder?.subtotal}</span>
              </div>

              {[
                { label: 'Customer Name', placeholder: 'Rahul Sharma', type: 'text', icon: User, val: checkoutName, set: setCheckoutName },
                { label: 'Mobile Number', placeholder: '9876543210', type: 'tel', icon: Phone, val: checkoutPhone, set: setCheckoutPhone },
              ].map(({ label, placeholder, type, icon: Icon, val, set }) => (
                <div key={label}>
                  <label className="block text-xs font-bold mb-2 uppercase tracking-wider" style={{ color: 'rgba(15, 23, 42, 0.5)' }}>
                    {label} <span style={{ color: 'rgba(15, 23, 42, 0.35)' }}>(Optional)</span>
                  </label>
                  <div className="relative">
                    <Icon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: 'rgba(15, 23, 42, 0.35)' }} />
                    <input type={type} value={val} onChange={e => set(e.target.value)} placeholder={placeholder}
                      className="glass-input w-full pl-11 pr-4 py-3 rounded-xl text-sm font-medium" />
                  </div>
                </div>
              ))}
            </div>

            <div className="p-5 flex gap-3" style={{ borderTop: '1px solid rgba(0, 0, 0, 0.08)' }}>
              <button onClick={() => setShowCheckoutModal(false)}
                className="px-5 py-3 rounded-xl font-bold text-sm transition-all"
                style={{ background: 'rgba(0,0,0,0.04)', color: 'rgba(15, 23, 42, 0.55)' }}>
                Cancel
              </button>
              <button onClick={handleConfirmPayment} className="btn-orange flex-1 py-3 rounded-xl text-sm">
                <span className="relative z-10">Confirm Payment</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
