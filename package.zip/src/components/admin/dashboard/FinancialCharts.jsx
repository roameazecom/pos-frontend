import { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { RefreshCw } from 'lucide-react';
import { usePosStore } from '../../../store/posStore';

export default function FinancialCharts({ date }) {
  const { orderHistory } = usePosStore();
  const [localDate, setLocalDate] = useState(date || new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' }));

  useEffect(() => {
    if (date) setLocalDate(date);
  }, [date]);

  const targetDate = localDate;
  const todayOrders = orderHistory.filter(o => {
    if (o.status !== 'paid') return false;
    const isoStr = o.created_at.includes('T') ? o.created_at : o.created_at.replace(' ', 'T') + 'Z';
    return new Date(isoStr).toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' }) === targetDate;
  });

  const paymentTotals = todayOrders.reduce((acc, order) => {
    const total = (order.subtotal || 0) + (order.tax_amount || 0);
    const type = order.payment_type || 'Cash';
    acc[type] = (acc[type] || 0) + total;
    acc.total += total;
    return acc;
  }, { Cash: 0, Card: 0, UPI: 0, total: 0 });

  const cashPct = paymentTotals.total > 0 ? (paymentTotals.Cash / paymentTotals.total) * 100 : 0;
  const cardPct = paymentTotals.total > 0 ? (paymentTotals.Card / paymentTotals.total) * 100 : 0;
  const upiPct = paymentTotals.total > 0 ? (paymentTotals.UPI / paymentTotals.total) * 100 : 0;

  // Simple static data for expenses since we don't have expenses in DB yet
  const expenseData = [
    { name: '10 AM', value: 0 },
    { name: '12 PM', value: 0 },
    { name: '2 PM', value: 0 },
    { name: '4 PM', value: 0 },
    { name: '6 PM', value: 0 },
  ];
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-6">
      {/* Payment Bifurcation */}
      <div className="bg-surface-100 border border-surface-200 rounded-xl shadow-sm overflow-hidden">
        <div className="p-4 border-b border-surface-200 flex items-center justify-between">
          <h3 className="font-semibold text-surface-900">Payment Bifurcation</h3>
          <div className="flex items-center space-x-2">
            <input 
              type="date"
              value={localDate}
              onChange={(e) => setLocalDate(e.target.value)}
              className="border border-slate-300 rounded-md text-sm p-1.5 focus:outline-none" 
            />
            <button className="p-1.5 border border-slate-300 rounded-md text-surface-400 hover:bg-surface-100">
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>
        <div className="p-6">
          {/* Stacked Bar graphic */}
          <div className="w-full h-8 flex rounded-sm overflow-hidden mb-8 bg-slate-100">
            {cashPct > 0 && <div className="bg-amber-400 h-full flex items-center justify-center text-white text-xs font-bold" style={{ width: `${cashPct}%` }}>{cashPct.toFixed(1)}%</div>}
            {cardPct > 0 && <div className="bg-cyan-400 h-full flex items-center justify-center text-white text-xs font-bold" style={{ width: `${cardPct}%` }}>{cardPct.toFixed(1)}%</div>}
            {upiPct > 0 && <div className="bg-blue-500 h-full flex items-center justify-center text-white text-xs font-bold" style={{ width: `${upiPct}%` }}>{upiPct.toFixed(1)}%</div>}
            {paymentTotals.total === 0 && <div className="bg-slate-300 h-full w-full flex items-center justify-center text-surface-400 text-xs font-bold">No Payments Yet</div>}
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center text-slate-700">
                <span className="w-3 h-3 rounded bg-amber-400 mr-2"></span> Cash
              </div>
              <span className="font-semibold">₹ {paymentTotals.Cash.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center text-slate-700">
                <span className="w-3 h-3 rounded bg-cyan-400 mr-2"></span> Card
              </div>
              <span className="font-semibold">₹ {paymentTotals.Card.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center text-slate-700">
                <span className="w-3 h-3 rounded bg-blue-500 mr-2"></span> UPI (Online)
              </div>
              <span className="font-semibold">₹ {paymentTotals.UPI.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between text-sm border-t border-surface-200 pt-3">
              <div className="flex items-center text-slate-700">
                <span className="w-3 h-3 rounded bg-green-500 mr-2"></span> Total Collection
              </div>
              <div className="flex items-center font-semibold text-surface-900">
                ₹ {paymentTotals.total.toFixed(2)}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Expenses & Withdrawal */}
      <div className="bg-surface-100 border border-surface-200 rounded-xl shadow-sm overflow-hidden flex flex-col">
        <div className="p-4 border-b border-surface-200 flex items-center justify-between">
          <h3 className="font-semibold text-surface-900">Expenses & Withdrawal</h3>
          <div className="flex items-center space-x-2">
             <input 
              type="date"
              value={localDate}
              onChange={(e) => setLocalDate(e.target.value)}
              className="border border-slate-300 rounded-md text-sm p-1.5 focus:outline-none" 
            />
            <button className="p-1.5 border border-slate-300 rounded-md text-surface-400 hover:bg-surface-100">
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>
        <div className="p-6 flex-1 flex flex-col justify-end">
           <div className="w-full h-48">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={expenseData} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94A3B8', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94A3B8', fontSize: 12}} ticks={[0, 10]} tickFormatter={(val) => val === 0 ? '0k' : `${val}k`} />
                <Tooltip />
                <Line type="monotone" dataKey="value" stroke="#3B82F6" strokeWidth={2} dot={{ r: 4, strokeWidth: 2 }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
           </div>
        </div>
      </div>
    </div>
  );
}
